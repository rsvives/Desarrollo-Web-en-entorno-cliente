function load() {
    let fixedListEl = document.getElementById('fixed-list');
    let orderedListEl = document.getElementById('ordered-list');
    let simulateSundayBtn = document.getElementById('simulate-sunday');
    let orderedList = []; // Lista de pedidos cargada al inicio
    let fixedList = [
        { name: 'Leche fresca botella 1,5L', quantity: 5 },
        { name: 'Huevos XL paquete', quantity: 1 },
        { name: 'Nutella bote', quantity: 2 },
    ];

    // Función para cargar la lista de pedidos desde localStorage
    function loadOrderedList() {
        let orders = [];
        let i = 0;
        while (localStorage.getItem('order_' + i) !== null) {
            orders.push(localStorage.getItem('order_' + i));
            i++;
        }
        return orders;
    }

    // Elimina la lista de pedidos de localStorage cada vez que se recarga la página
    // Esto asegura que los datos anteriores se borren al recargar
    localStorage.clear();

    // Función para mostrar la lista fija de productos
    function displayFixedList() {
        fixedListEl.innerHTML = ''; // Limpiar la lista actual
        for (let i = 0; i < fixedList.length; i++) {
            let item = fixedList[i];
            let li = document.createElement('li');
            li.textContent = item.name + ' : ' + item.quantity;
            li.onclick = function () {
                promptForOrder(item); // Llama a la función cuando se hace clic en un producto
            };
            fixedListEl.appendChild(li);
        }
    }

    // Función para pedir detalles sobre el pedido y guardarlos en localStorage
    function promptForOrder(item) {
        let supermarket = prompt('¿Dónde compraste este producto?');
        let today = new Date();
        let dayOfWeek = today.getDay();
        let order = item.name + '|' + item.quantity + '|' + supermarket + '|' + dayOfWeek;

        // Si el supermercado es Mercadona, restamos uno de la cantidad del producto en fixedList
        if (supermarket.toLowerCase() === 'mercadona') {
            for (let i = 0; i < fixedList.length; i++) {
                if (fixedList[i].name === item.name && fixedList[i].quantity > 0) {
                    fixedList[i].quantity -= 1; 
                }
            }
        }

        localStorage.setItem('order_' + orderedList.length, order);
        orderedList.push(order);

        displayOrderedList();
        displayFixedList();
    }

    function displayOrderedList() {
        orderedListEl.innerHTML = ''; 
        for (let i = 0; i < orderedList.length; i++) {
            let item = orderedList[i].split('|');
            let li = document.createElement('li');
            li.textContent = item[0] + ' : ' + item[1] + ' - ' + item[2] + ' (' + item[3] + ')';
            orderedListEl.appendChild(li);
        }
    }

	function simulateSunday() {
        alert('Es Domingo a las 23:59');
        let i = 0;
        while (localStorage.getItem('order_' + i) !== null) {
            localStorage.removeItem('order_' + i);
            i++;
        }
        orderedList = [];
        displayOrderedList();
        displayFixedList();
    };
    simulateSundayBtn.onclick = simulateSunday

    orderedList = loadOrderedList();

    displayFixedList();
    displayOrderedList();
}
